library(readxl)
MediSync_DataSet <- read_excel("MediSync_DataSet.xlsx")
View(MediSync_DataSet) 
summary(MediSync_DataSet)
str(MediSync_DataSet)


MediSync_DataSet$LocationTime <- as.POSIXct(MediSync_DataSet$LocationTime, format="%Y-%m-%d %H:%M:%S")

#TEMPORAL ANALYSIS
# Create Date and Time attributes
MediSync_DataSet$Date <- as.Date(MediSync_DataSet$LocationTime)
MediSync_DataSet$Time <- format(MediSync_DataSet$LocationTime, format="%H:%M:%S")

# MediSync_DataSet$Date is a Date type attribute
MediSync_DataSet$DayOfWeek <- weekdays(MediSync_DataSet$Date)

# Plot incidents by day of the week
library(ggplot2)
ggplot(MediSync_DataSet, aes(x = DayOfWeek, fill = EmergencyStatus)) +
  geom_bar(position = "stack") +
  labs(title = "Emergency Incidents by Day of the Week")


MediSync_DataSet <- MediSync_DataSet[complete.cases(MediSync_DataSet), ]
MediSync_DataSet <- MediSync_DataSet[!apply(is.na(MediSync_DataSet), 1, all), ]

MediSync_DataSet$Time <- as.POSIXct(MediSync_DataSet$Time, format="%H:%M:%S")
library(ggplot2)
ggplot(MediSync_DataSet, aes(x = DayOfWeek, fill = EmergencyStatus)) +
  geom_bar(position = "stack") +
  labs(title = "Emergency Incidents by Day of the Week")
facet_wrap(~format(MediSync_DataSet$Time, "%H:%M"))

# Assuming your_data$Time is a character vector
MediSync_DataSet$Time <- sub(".* ", "", MediSync_DataSet$Time)
MediSync_DataSet$Time <- as.POSIXct(MediSync_DataSet$Time, format="%H:%M:%S")

# Assuming your_data$Time is a character vector
MediSync_DataSet$Time <- strptime(MediSync_DataSet$Time, format="%Y-%m-%d %H:%M:%S")

# Extract the time part
MediSync_DataSet$Time <- format(MediSync_DataSet$Time, format="%H:%M:%S")

library(ggplot2)
ggplot(MediSync_DataSet, aes(x = format(Time, "%H"), fill = EmergencyStatus)) +
  geom_bar(position = "stack") +
  labs(title = "Emergency Incidents by Hour and EmergencyStatus") +
  scale_x_discrete(name = "Hour", limits = sprintf("%02d", 0:23))

#GEOSPATIAL ANALYSIS
library(ggplot2)
ggplot(MediSync_DataSet, aes(x = Longitude, y = Latitude, color = EmergencyStatus)) +
  geom_point() +
  labs(title = "Geospatial Distribution of Ambulance Incidents")

# Plot speed distribution
ggplot(MediSync_DataSet, aes(x = Speed)) +
  geom_histogram(binwidth = 5, fill = "blue", color = "black", alpha = 0.7) +
  labs(title = "Distribution of Ambulance Speeds")

# Plot heading distribution
ggplot(MediSync_DataSet, aes(x = Heading)) +
  geom_histogram(binwidth = 10, fill = "green", color = "black", alpha = 0.7) +
  labs(title = "Distribution of Ambulance Headings")

# Plot Emergency Types
ggplot(MediSync_DataSet, aes(x = EmergencyType, fill = EmergencyStatus)) +
  geom_bar(position = "stack") +
  labs(title = "Emergency Types and Status")



