# Descriptive statistics for each attribute
summary(MediSync_DataSet[c("DriverBehavior", "StaffBehavior", "AbilityToTrack", "FacilitiesinAmbulance", "EaseOfUse")])

# Correlation matrix
cor_matrix <- cor(MediSync_DataSet[c("DriverBehavior", "StaffBehavior", "AbilityToTrack", "FacilitiesinAmbulance", "EaseOfUse")])
cor_matrix

# Segment the data by EmergencyStatus and calculate mean ratings
segmented_mean <- aggregate(cbind(DriverBehavior, StaffBehavior, AbilityToTrack, FacilitiesinAmbulance, EaseOfUse) ~ Destination, MediSync_DataSet, mean)
segmented_mean

# Segment the data by EmergencyStatus and calculate mean ratings
segmented_mean <- aggregate(cbind(DriverBehavior, StaffBehavior, AbilityToTrack, FacilitiesinAmbulance, EaseOfUse) ~ DriverID, MediSync_DataSet, mean)
segmented_mean

# Segment the data by EmergencyStatus and calculate mean ratings
segmented_mean <- aggregate(cbind(DriverBehavior, StaffBehavior, AbilityToTrack, FacilitiesinAmbulance, EaseOfUse) ~ AmbulanceType, MediSync_DataSet, mean)
segmented_mean


# Calculate and print the aggregate trustworthiness score
trustworthiness_score <- rowMeans(MediSync_DataSet[c("DriverBehavior", "StaffBehavior", "AbilityToTrack", "FacilitiesinAmbulance", "EaseOfUse")], na.rm = TRUE)
print(trustworthiness_score)

# Delete the TrustworthinessScore attribute
rm(MediSync_DataSet$TrustworthinessScore)

# Calculate an aggregate trustworthiness score
MediSync_DataSet$TrustworthinessScore <- rowMeans(MediSync_DataSet[c("DriverBehavior", "StaffBehavior", "AbilityToTrack", "FacilitiesinAmbulance", "EaseOfUse")], na.rm = TRUE)
